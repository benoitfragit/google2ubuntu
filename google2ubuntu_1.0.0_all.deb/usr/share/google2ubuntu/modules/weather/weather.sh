#!/bin/bash

xdg-open https://www.google.fr/#q=m%C3%A9t%C3%A9o+$1&safe=off &

exit 0
